package a2;

public class Avatar extends Jumpable
{
	
}
