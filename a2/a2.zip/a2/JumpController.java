package a2;

import sage.scene.Controller;

public class JumpController extends Controller 
{
	
	
	
	@Override
	public void update(double arg0) 
	{
		// TODO Auto-generated method stub

	}

}
