package a2;

import sage.scene.Group;

public class PyramidGroup extends Group 
{

}
