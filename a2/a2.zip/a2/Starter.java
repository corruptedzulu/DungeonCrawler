/*
 * Spencer Underhill
 * CSC165
 * A1
 */

package a2;

public class Starter 
{

	public static void main(String [] args)
	{
		new DogCatcher3D().start();
	}
}
