/*
 * Spencer Underhill
 * CSC165
 * A1
 */

package a2;

import sage.event.IEventListener;
import sage.event.IGameEvent;

public class OtherAnimal implements IEventListener
{

	@Override
	public boolean handleEvent(IGameEvent event) 
	{
		
		return false;
	}

}
